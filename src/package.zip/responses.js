var Alexa = require('alexa-sdk');
exports.sayHello = function () {
      
        var result = (':tell', 'Hello Harrison, how are you today? Are you ready for your gig?');
    	return result;
    };